def process_file(file_name):
    data = []
    data1 = []
    with open(file_name) as f:
        for line in f:
            print(line)
            parts = line.split(';')
            data.append(parts)
            #if parts[0][0] == 'Harmonica':
              #  f.readline()


    return data


#user_input1 = input("Enter a muscial instrument: ")
#user_input2 = input('Enter a song: ')
data = process_file('Note.txt')
print(data)
#if user_input1 == 'Harmonica' and user_input2 == 'Godfather':
#print(data[1:10])
i = 0
n = 1
while i < len(data[0]):
    print(data[n])
    n += 2
    i += 1
#print(data[1])