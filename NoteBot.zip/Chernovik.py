def process_file(file_name):
    data = []
    d = {}
    with open(file_name) as f:
        data = f.read().splitlines()
        for line in f:
            parts = line.split(';')
            data.append(parts)


    return data


i = 0
n = 0
user_input1 = input("Enter a muscial instrument: ")
user_input2 = input('Enter a song: ')
data = process_file('Note.txt')
#print(data)
if user_input1 == 'Harmonica' and user_input2 == 'Godfather':
    print(data[0:15])
if user_input1 == 'Harmonica' and user_input2 == 'March of Mendelssohn':
    print(data[16:22])
if user_input1 == 'Harmonica' and user_input2 == 'Imperial march':
    print(data[33:37])