def process_file(file_name):
    data = []
    with open(file_name) as f:
        data = f.read().splitlines()
        for line in f:
            parts = line.split(';')
            data.append(parts)
    return data


print(process_file('Note.txt'))


def song_output():
    user_input1 = input("Enter a musical instrument: ")
    user_input2 = input('Enter a song: ')
    data = process_file('Note.txt')
    if user_input1 == 'Harmonica' and user_input2 == 'Godfather':
        print(data[0:14])
    if user_input1 == 'Harmonica' and user_input2 == 'March of Mendelssohn':
        print(data[16:20])
    if user_input1 == 'Harmonica' and user_input2 == 'Imperial march':
        print(data[21:26])


song_output()
